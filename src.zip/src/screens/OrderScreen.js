import { Text, View } from 'native-base'
import React from 'react'

function OrderScreen() {
  return (
    <View>
        <Text>OrderScreen</Text>
    </View>
  )
}

export default OrderScreen