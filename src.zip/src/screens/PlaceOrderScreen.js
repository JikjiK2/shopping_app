import { Text, View } from 'native-base'
import React from 'react'

function PlaceOrderScreen() {
  return (
    <View>
        <Text>PlaceOrderScreen</Text>
    </View>
  )
}

export default PlaceOrderScreen