import { Text, View } from 'native-base'
import React from 'react'

function ShippingScreen() {
  return (
    <View>
        <Text>ShippingScreen</Text>
    </View>
  )
}

export default ShippingScreen