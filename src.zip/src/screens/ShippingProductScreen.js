import { Text, View } from 'native-base'
import React from 'react'

function ShippingProductScreen() {
  return (
    <View>
        <Text>ShippingProductScreen</Text>
    </View>
  )
}

export default ShippingProductScreen