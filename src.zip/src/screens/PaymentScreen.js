import { Text, View } from 'native-base'
import React from 'react'

function PaymentScreen() {
  return (
    <View>
        <Text>PaymentScreen</Text>
    </View>
  )
}

export default PaymentScreen