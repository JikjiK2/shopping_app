const Colors = {
    main : "#007060",
    black : "#000000",
    white : "#ffffff",
    deepestGray : "#cccccc",
    orange: "#ffa500",
    subGreen: "#adcaca",
    red: "#ff0000",
    blue: "#0000ff"
}

export default Colors;